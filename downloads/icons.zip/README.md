# Phosphor Icons Setup Guide

**Organize Files**

1. Place the `Phosphor-icon.js` file into your project's JavaScript (js) folder.
2. Create a folder named `icons` in the root directory of your project.

---

**Linking to HTML**

Add the following script tag at the end of the `<body>` section in your `index.html` file:

```html
<script src="./js/phosphor-icons.js"></script>
```

---

**Usage**

Now you can use Phosphor Icons in your HTML by referencing the icon files from the icons folder.

Example:

```html
<i class="ph-icon ph-heart-fill"></i>
```

This will render a heart icon filled.

---

**Test**

Reload your HTML file in the browser to ensure the icons are displaying correctly.

---

**Additional Notes**

- Ensure the file paths are correct in your project directory structure.
- You can explore the available icons and their usage from the Phosphor Icons documentation.